anim = 0
time = 0
