import numpy as np
import primitif.utility
import primitif.line
import py5
import math

def draw_persegi(width, height, margin, c=[0,0,0,255]):
    py5.fill(0,113,45)
    py5.square(620, 150, 200)
    py5.rect(620,275, 130,50)