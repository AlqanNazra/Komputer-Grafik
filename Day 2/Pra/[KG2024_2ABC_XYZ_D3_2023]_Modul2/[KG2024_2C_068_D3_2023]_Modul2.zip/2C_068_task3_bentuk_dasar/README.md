# README

## Task 3 Bentuk Dasar

### Persegi
Parameter xa, ya, panjang

### Persegi Panjang
Parameter xa, ya, panjang, lebar

### Segitiga Siku
Parameter xa, ya, alas, tinggi

### Trapesium Siku
Parameter xa, ya, aa, ab, t

### Jajar Genjang
Parameter xa, ya, a, b, t

### Kali
Parameter xa, ya, r


