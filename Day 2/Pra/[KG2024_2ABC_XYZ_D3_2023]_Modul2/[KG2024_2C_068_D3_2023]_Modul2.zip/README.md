# Task 0 - 2

## Task 0-3
1. Perhatikan Kode Berikut
2. Jalankan
3. Hapus konten draw(): ganti dengan pass
```python
draw():
    pass
```
4. Pada fungsi setup panggil fungsi line_dda dengan skenario berikut:
    dx=dy
    dx=0
    dy=0
    0 < m <=1
    m > 1
    m negative

## Pertanyaan
1. Jelaskan Perbedaan Line DDA, Line Bres V1 dan Line Bres V2
2. Observasi hasil-hasil skenario pada task 0-2, 
analisa kelebihan dan kekurangan kedua algoritma tersebut.