import py5
import primitif.line
import primitif.basic

import math

def setup():
    py5.size(800, 600)
    py5.rect_mode(py5.CENTER) 
    py5.background(191)

def draw():
    pass

py5.run_sketch()

