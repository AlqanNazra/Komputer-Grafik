anim = 0
times = 15
